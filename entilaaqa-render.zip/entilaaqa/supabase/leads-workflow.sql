-- شغّله مرة واحدة: Supabase > SQL Editor > الصق > Run
-- يفعّل متابعة العملاء (الحالة والملاحظات) في لوحة التحكم.
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS lead_status text NOT NULL DEFAULT 'new';
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS updated_at timestamptz;
