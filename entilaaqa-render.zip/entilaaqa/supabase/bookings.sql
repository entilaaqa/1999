-- اختياري: الدالة تنشئ هذا الجدول تلقائياً عند أول حجز.
-- استخدم هذا الملف فقط إذا أردت إنشاءه يدوياً: Supabase > SQL Editor > الصق > Run.

CREATE TABLE IF NOT EXISTS public.bookings (
  id                   serial PRIMARY KEY,
  booking_id           uuid NOT NULL UNIQUE,
  created_at           timestamptz NOT NULL DEFAULT now(),
  language             text NOT NULL,
  name                 text NOT NULL,
  whatsapp             text NOT NULL,
  email                text NOT NULL,
  current_status       text NOT NULL,
  current_status_code  integer NOT NULL,
  main_goal            text NOT NULL,
  biggest_challenge    text NOT NULL,
  monthly_income       text NOT NULL,
  monthly_income_code  integer NOT NULL,
  ready_to_invest      text NOT NULL,
  ready_to_invest_code integer NOT NULL,
  session_start        text,
  session_end          text,
  session_tz           text,
  page_url             text,
  referrer             text,
  utm                  jsonb NOT NULL DEFAULT '{}',
  user_agent           text,
  country              text
);

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
